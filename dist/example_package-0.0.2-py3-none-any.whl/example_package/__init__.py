"""Example package for Cloudsmith assessment."""

__version__ = "0.0.1" 